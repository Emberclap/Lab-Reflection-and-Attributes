﻿namespace AuthorProblem
{
    [Author("Viktor")]
    [Author("Students")]
    public class StartUp
    {
        static void Main(string[] args)
        {
            Tracker tracker = new Tracker();
            tracker.PrintMethodsByAuthor();


        }
        [Author("blabla")]
        public void CustomMethod() 
        {

        }
    }
}